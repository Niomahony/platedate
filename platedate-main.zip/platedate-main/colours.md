Our colour palette:

Navy Blue (#003366)

Creamy White (#F5F5DC)

Burgundy (#800020)

Sage Green (#9dc183)

Soft Gray (#B1B1B1)

Rose Gold (#B76E79)
